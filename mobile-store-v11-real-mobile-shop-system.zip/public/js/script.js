
let products=[];

async function load(){
const res=await fetch("/api/products");
products=await res.json();
render(products);
}

function render(list){
const c=document.getElementById("products");
c.innerHTML="";

list.forEach(p=>{
const d=document.createElement("div");
d.className="card";
d.innerHTML=`
<img src="${p.img}">
<h3>${p.name}</h3>
<p>${p.type}</p>
<p>₹${p.price}</p>
<button onclick='order("${p.name}")'>Order</button>
`;
c.appendChild(d);
});
}

function order(name){
alert("Order placed for "+name);
fetch("/api/order",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({product:name})
});
}

function searchProduct(){
const q=document.getElementById("search").value.toLowerCase();
render(products.filter(p=>p.name.toLowerCase().includes(q)));
}

load();
